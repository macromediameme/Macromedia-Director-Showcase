//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Eventtst.rc
//
#define IDB_BITMAP1                     101
#define IDD_DIALOG1                     102
#define IDD_DIALOG2                     103
#define IDB_BITMAP2                     104
#define IDB_BITMAP3                     105
#define IDI_ICON1                       106
#define IDB_BITMAP4                     107
#define IDB_BITMAP5                     109
#define IDB_BITMAP6                     110
#define IDC_USER1                       1001
#define IDC_RADIO1                      1002
#define IDC_RADIO2                      1003
#define IDC_BUTTON1                     1004
#define IDC_BUTTON2                     1005
#define IDC_BUTTON3                     1006
#define IDC_SCROLLBAR1                  1007
#define IDC_BUTTON4                     1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif


// Guids can cause trouble with XSupport

#define INITGUID

#include "Dialog.h"
#include "Sprite.h"
#include "mui.h"
#include "MuiView.h"

#undef INITGUID
//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Tallwide.rc
//
#define IDD_DIALOG1                     101
#define IDI_ICON2                       109
#define IDB_BITMAP14                    112
#define IDI_ICON1                       113
#define IDB_BITMAP15                    115
#define IDB_BITMAP16                    116
#define IDD_DIALOG2                     130
#define IDB_BITMAP1                     510
#define IDB_BITMAP7                     511
#define IDB_BITMAP2                     512
#define IDB_BITMAP8                     513
#define IDB_BITMAP3                     514
#define IDB_BITMAP9                     515
#define IDB_BITMAP4                     516
#define IDB_BITMAP10                    517
#define IDB_BITMAP5                     518
#define IDB_BITMAP11                    519
#define IDB_BITMAP6                     520
#define IDB_BITMAP12                    521
#define IDB_BITMAP13                    522
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_EDIT3                       1002
#define IDC_EDIT4                       1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        117
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

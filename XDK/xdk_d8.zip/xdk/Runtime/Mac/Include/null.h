/*  Metrowerks Standard Library  Version 2.2  1997 October 17  */

/*
 *	null.h
 *	
 *		Copyright � 1995-1997 Metrowerks, Inc.
 *		All rights reserved.
 */
 
#ifndef NULL

#include <ansi_parms.h>                 /* mm 970905*/

#define NULL	0L

#endif /* ndef NULL */

/*     Change record
 * mm 970905  added include of ansi_parms.h to avoid need for prefix file
 */

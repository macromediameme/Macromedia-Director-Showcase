/*
 *	File:		altivec.h
 *				�1998 Metrowerks Inc. All rights reserved
 *
 *	Content:	altivec support for Metrowerks C++ (PowerPC)
 * 
 */
 
 #if __MWERKS__
 	#if __VEC__
		#ifndef vector
		#define vector __vector
		#endif
 	#endif
 #endif